def main(*args):
    print(args)
